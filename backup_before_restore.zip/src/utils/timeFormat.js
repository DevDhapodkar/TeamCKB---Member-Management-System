/**
 * Formats decimal hours (e.g., 2.78) into a human-readable string (e.g., "2h 47m").
 * @param {number|string} decimalHours 
 * @returns {string}
 */
export const formatHours = (decimalHours) => {
  const total = parseFloat(decimalHours || 0);
  if (isNaN(total) || total === 0) return "0h";
  
  const hours = Math.floor(total);
  const minutes = Math.round((total - hours) * 60);
  
  if (hours === 0) return `${minutes}m`;
  if (minutes === 0) return `${hours}h`;
  return `${hours}h ${minutes}m`;
};
